<?php

namespace App\Data\Models\Team;

use App\Data\Models\BaseModel;

class BaseTeamModel extends BaseModel {

}
