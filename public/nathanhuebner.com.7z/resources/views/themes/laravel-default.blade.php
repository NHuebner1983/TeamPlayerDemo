@include('themes.laravel-default.header')

@yield('content')

@include('themes.laravel-default.footer')
