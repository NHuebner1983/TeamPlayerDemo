<script src="{!! mix('/js/app.js') !!}"></script>

</body>
</html>
