@section('css')
    <style>
        .team-item, .player-item {
            cursor: pointer;
        }
        .player-item .badge {
            font-size: 13px;
        }
    </style>
@endsection
